//Developed by Juraj Kebis in April 2023
import SwiftUI
import UIKit
import PlaygroundSupport
import SpriteKit

struct ContentView: View {
    var scene: SKScene {
        let scene = PlantisScene()
        scene.size = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        scene.scaleMode = .fill
        return scene
    }
    var body: some View {
        GeometryReader { (geometry) in
            SpriteView(scene: self.scene)
                .ignoresSafeArea()
                .frame(width: geometry.size.width, height: geometry.size.height, alignment: .center)
        }
    }
}

//MAIN
class PlantisScene:SKScene {
    private var presentedScene:PlScenes = .start
    private var startNode=StartNode()
    private var menuNode=MenuNode()
    private var plantNode=PlantNode()
    
    private var scenSize=CGSize(width: 1, height: 1)
    
    override func didMove(to view:SKView){
        print("DidMove")
        scene?.size = view.bounds.size
        scene?.scaleMode = .aspectFill
        scenSize=view.bounds.size
        //------
        //fonts
        let fontURL = Bundle.main.url(forResource: "CabinSketch-Regular", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        let fontURL2 = Bundle.main.url(forResource: "CabinSketch-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL2! as CFURL, CTFontManagerScope.process, nil)
        //other
        startNode.create(sceneSize:scenSize)
        menuNode.create(sceneSize:scenSize)
        self.addChild(startNode)
        self.backgroundColor = UIColor(hue: 55/360, saturation: 0.09, brightness: 1, alpha: 1)
    }
    func createNewNode(type:Int) {    //0-startNode, 1-menuNode,2-plantNode
        if type==0 {
            self.startNode=StartNode()
        } else if type==1 {
            self.menuNode=MenuNode()
        } else if type == 2 {
            self.plantNode=PlantNode()
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.previousLocation(in: self)
            let node = self.nodes(at: location).first
            if presentedScene == .start && startNode.canClick{
                startNode.screen.run(.fadeAlpha(to: 1, duration: 0.4),completion:{
                    self.presentedScene = .menu
                    self.addChild(self.menuNode)
                    self.startNode.removeFromParent()
                })
            } else if presentedScene == .menu && menuNode.clicked==false{
                var pickedPlant=true
                if node?.name == "package1" {
                    menuNode.changeTexture(package: 0, on: true)
                }else {
                    pickedPlant=false
                }
                if pickedPlant {
                    menuNode.screen.run(.wait(forDuration: 1),completion:{
                        [self]in
                        menuNode.screen.run(.fadeAlpha(to: 1, duration: 0.4),completion: {
                            [self]in
                            menuNode.clicked=true
                            presentedScene = .plant
                            createNewNode(type: 2)
                            plantNode.create(sceneSize: scenSize)
                            self.startNode.removeFromParent()
                            self.menuNode.removeFromParent()
                            self.addChild(plantNode)
                        })
                    })
                }
                
            } else if presentedScene == .plant {
                if node?.name == "dig" {
                    if plantNode.plantEngine.finishedTutorial{
                        if  !plantNode.blockedButtons {
                            plantNode.plantEngine.digg()
                            self.plantNode.blockButtons(block: true)
                            plantNode.buttons[4].run(.wait(forDuration: 2),completion:{
                                self.plantNode.blockButtons(block: false)
                            })
                        }
                    } else {
                        if !plantNode.plantEngine.didDigholeonce && !plantNode.plantEngine.didDigholetwice{
                            plantNode.plantEngine.digHole(first: true)
                            plantNode.changeText(to: 1)
                        } else if plantNode.plantEngine.didDigholeonce && !plantNode.plantEngine.didDigholetwice {
                            plantNode.plantEngine.digHole(first: false)
                            plantNode.buttons[1].texture = plantNode.kopBTex[1]
                            plantNode.buttons[4].texture = plantNode.semBTex[0]
                            plantNode.changeText(to: 2)
                        }
                        if plantNode.plantEngine.addedPlant && plantNode.plantEngine.didDigholetwice{
                            plantNode.plantEngine.putDirt()
                            plantNode.buttons[1].texture = plantNode.kopBTex[1]
                            plantNode.buttons[0].texture = plantNode.watBTex[0]
                            plantNode.changeText(to: 4)
                        }
                    }
                } else if node?.name == "zasadit" && !plantNode.plantEngine.finishedTutorial{
                    if plantNode.plantEngine.didDigholetwice && !plantNode.plantEngine.addedPlant{
                        plantNode.plantEngine.addPlant()
                        plantNode.buttons[1].texture = plantNode.kopBTex[0]
                        plantNode.buttons[4].texture = plantNode.semBTex[1]
                        plantNode.changeText(to: 3)
                    }
                } else if node?.name == "water" {
                    if plantNode.plantEngine.finishedTutorial{
                        if !plantNode.blockedButtons {
                            plantNode.plantEngine.watered()
                            self.plantNode.blockButtons(block: true)
                            plantNode.buttons[4].run(.wait(forDuration: 2),completion:{
                                self.plantNode.blockButtons(block: false)
                            })
                        }
                    } else {
                        if !plantNode.plantEngine.didDigholetwice && plantNode.plantEngine.addedPlant{
                            plantNode.plantEngine.firstWatered()
                            plantNode.buttons[4].run(.wait(forDuration: 90),completion:{
                                self.plantNode.changeText(to: 9)
                                self.plantNode.removeAllActions()
                                self.plantNode.plantEngine.removeAllActions()
                            })
                            plantNode.changeText(to: 5)
                            plantNode.startClock()
                            plantNode.buttons[1].texture = plantNode.kopBTex[0]
                            plantNode.buttons[0].texture = plantNode.watBTex[0]
                            self.plantNode.blockButtons(block: true)
                            plantNode.buttons[4].run(.wait(forDuration: 2),completion:{
                                self.plantNode.blockButtons(block: false)
                                self.plantNode.buttons[4].run(.wait(forDuration: 8),completion: {
                                    self.plantNode.changeText(to: 6)
                                    self.plantNode.buttons[4].run(.wait(forDuration: 12),completion: {
                                        self.plantNode.changeText(to: 7)
                                        self.plantNode.buttons[4].run(.wait(forDuration: 12),completion: {
                                            self.plantNode.changeText(to: 8)
                                            self.plantNode.buttons[4].run(.wait(forDuration: 4),completion: {
                                                self.plantNode.changeText(to: -1)
                                                
                                            })
                                        })
                                    })
                                })
                            })
                        }
                    }
                } else if node?.name == "sprej" && plantNode.plantEngine.finishedTutorial && !plantNode.blockedButtons {
                    plantNode.plantEngine.sprej()
                    self.plantNode.blockButtons(block: true)
                    plantNode.buttons[4].run(.wait(forDuration: 2),completion:{
                        self.plantNode.blockButtons(block: false)
                    })
                } else if node?.name == "noznice" && plantNode.plantEngine.finishedTutorial && !plantNode.blockedButtons{
                    plantNode.plantEngine.strihanie()
                    self.plantNode.blockButtons(block: true)
                    plantNode.buttons[4].run(.wait(forDuration: 2),completion:{
                        self.plantNode.blockButtons(block: false)
                    })
                } else if node?.name == "butonMenu2" || node?.name == "butonMenu"{
                    presentedScene = .menu
                    createNewNode(type: 1)
                    menuNode.create(sceneSize: scenSize)
                    self.startNode.removeFromParent()
                    self.plantNode.removeFromParent()
                    self.addChild(menuNode)
                } 
            }
        }
    }
    
}


class StartNode:SKNode {
    public var canClick=false
    private var title=SKLabelNode()
    private var subtitle=SKLabelNode()
    private var author=SKLabelNode()
    private var titleImg=SKSpriteNode()
    private var textInstr=SKLabelNode()
    public var screen=SKSpriteNode()
    private var plantTxrs = [SKTexture(imageNamed: "pl1.png"),SKTexture(imageNamed:"pl2"),SKTexture(imageNamed:"pl3" ),SKTexture(imageNamed:"pl4")]
    
    private var plantTx=SKTexture(imageNamed: "")
    func create(sceneSize:CGSize) {
        
        title = SKLabelNode(fontNamed: "CabinSketch-Regular")
        title.text = "PLANTIES"
        title.fontColor = .black
        title.fontSize = sceneSize.width/7
        title.position = CGPoint(x: sceneSize.width/2, y:sceneSize.height*0.75)
        
        subtitle = SKLabelNode(fontNamed: "CabinSketch-Regular")
        subtitle.text = "Let's plant a tree!"
        subtitle.fontColor = .black
        subtitle.fontSize = sceneSize.width/26
        subtitle.position = CGPoint(x: sceneSize.width/2, y:sceneSize.height*0.66)
        
        screen.size=sceneSize
        screen.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        screen.color = UIColor(hue: 55/360, saturation: 0.09, brightness: 1, alpha: 1)
        screen.zPosition=200
        screen.alpha=0
        
        author = SKLabelNode(fontNamed: "CabinSketch-Regular")
        author.text = "Created by Juraj Kebis | for Swift Student Challenge 2023"
        author.fontColor = .black
        author.fontSize = sceneSize.width/50
        author.position = CGPoint(x: sceneSize.width/2, y:sceneSize.height*0.08)
        
        titleImg=SKSpriteNode(texture: plantTxrs.first)
        titleImg.size = CGSize(width: sceneSize.width/4*0.8, height: sceneSize.height/4)
        titleImg.position = CGPoint(x: sceneSize.width/2, y: sceneSize.height*0.44)
        titleImg.run(.wait(forDuration: 0.5),completion: { [self] in
            titleImg.run(.animate(with: plantTxrs, timePerFrame: 0.5))
        })
        textInstr = SKLabelNode(fontNamed: "CabinSketch-Regular")
        textInstr.text = "CLICK TO CONTINUE"
        textInstr.fontColor = .black
        textInstr.fontSize = 20
        textInstr.position = CGPoint(x: sceneSize.width/2, y: sceneSize.height*0.2)
        textInstr.isHidden=true
        let seq = [SKAction.fadeIn(withDuration: 0),SKAction.wait(forDuration: 0.7),SKAction.fadeOut(withDuration: 0),SKAction.wait(forDuration: 0.7)]
        textInstr.run(.wait(forDuration: 2),completion: {
            self.canClick=true
            self.textInstr.isHidden=false
            self.textInstr.run(.repeatForever(.sequence(seq)))
        })
        self.addChild(screen)
        self.addChild(title)
        self.addChild(author)
        self.addChild(titleImg)
        self.addChild(subtitle)
        self.addChild(textInstr)
    }
}
class MenuNode:SKNode {
    private var title=SKLabelNode()
    private var plants=[SKSpriteNode]()
    private var textInstr=SKLabelNode()
    private var plantTx=SKTexture(image: #imageLiteral(resourceName: "cherries1.png"))
    private var plantTx2=SKTexture(image: #imageLiteral(resourceName: "cherries2.png"))
    public var screen=SKSpriteNode()
    public var clicked=false
    
    func create(sceneSize:CGSize) {
        print("MenuNode")
        title = SKLabelNode(fontNamed: "CabinSketch-Regular")
        title.text = "WE CAN PLANT CHERRY TREE"
        title.fontColor = .red
        title.fontSize = 40
        title.position = CGPoint(x: sceneSize.width/2, y:sceneSize.height*0.8)
        
        screen.size=sceneSize
        screen.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        screen.color = UIColor(hue: 55/360, saturation: 0.09, brightness: 1, alpha: 1)
        screen.zPosition=200
        screen.alpha=1
        self.addChild(screen)
        createPlants(sceneSize:sceneSize)
        
        textInstr = SKLabelNode(fontNamed: "CabinSketch-Regular")
        textInstr.text = "CLICK ON THE PACKAGE TO OPEN IT"
        textInstr.fontColor = .black
        textInstr.fontSize = 20
        textInstr.position = CGPoint(x: sceneSize.width/2, y: sceneSize.height*0.17)
        
        self.addChild(title)
        self.addChild(textInstr)
        screen.run(.fadeAlpha(to: 0, duration: 0.4))
    }
    func changeTexture(package:Int,on:Bool) {
        plants[package].texture = on ? plantTx2 : plantTx
    }
    private func createPlants(sceneSize:CGSize) {
        plants.append(SKSpriteNode(texture: plantTx, size: CGSize(width: sceneSize.width/3*0.656, height: sceneSize.width/3)))
        plants.last?.position = CGPoint(x: sceneSize.width*0.5, y: sceneSize.height*0.5)
        self.addChild(plants.last!)
        plants.last?.name = "package1"
        
        
    }
}
class PlantNode:SKNode {
    public var blockedButtons=false
    
    private var listok=SKSpriteNode()
    private var instrukcie=SKLabelNode()
    private var textDole=SKLabelNode()
    public var buttons=[SKSpriteNode]()
    private var hodiny=SKSpriteNode()
    private var rucicka=SKSpriteNode()
    private var timePassed=SKLabelNode()
    public var screen = SKSpriteNode()
    public var butonMenu=SKSpriteNode()
    public var texts=[String]()
    
    var plantEngine=PlantEngine()
    
    
    public var watBTex=[SKTexture(image: #imageLiteral(resourceName: "waterB1.png")),SKTexture(image: #imageLiteral(resourceName: "waterB2.png")),SKTexture(image: #imageLiteral(resourceName: "waterB3.png"))]
    public var kopBTex=[SKTexture(image: #imageLiteral(resourceName: "kopaB1.png")),SKTexture(image: #imageLiteral(resourceName: "kopaB2.png")),SKTexture(image: #imageLiteral(resourceName: "kopaB3.png"))]
    public var nozBTex=[SKTexture(image: #imageLiteral(resourceName: "noznicB1.png")),SKTexture(image: #imageLiteral(resourceName: "noznicB2.png")),SKTexture(image: #imageLiteral(resourceName: "noznicB3.png"))]
    public var sprejBTex=[SKTexture(image: #imageLiteral(resourceName: "sprejB1.png")),SKTexture(image: #imageLiteral(resourceName: "sprejB2.png")),SKTexture(image: #imageLiteral(resourceName: "sprejB3.png"))]
    public var semBTex=[SKTexture(image: #imageLiteral(resourceName: "semiacB1.png")),SKTexture(image: #imageLiteral(resourceName: "semiacB2.png")),SKTexture(image: #imageLiteral(resourceName: "semiacB3.png"))]
    
    public var instrSeq:Int=0
    
    private var sizeScn=CGSize(width: 1.0, height: 1.0)
    
    func create(sceneSize:CGSize) {
        sizeScn=sceneSize
        listok.texture=SKTexture(image: #imageLiteral(resourceName: "papier.png"))
        listok.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height*0.88)
        listok.size.width=sceneSize.width*0.78
        listok.size.height=sceneSize.width*0.78*0.2
        self.addChild(listok)
        texts.append("To start with planting a Cherry tree, we need to dig a hole.\nOn the left side is the panel with buttons. Click on the shovel button.")
        texts.append("Click one more time to dig a deeper hole.")
        texts.append("Perfect! Now we can plant the seed.\nClick on the top button in the panel to plant a seed.")
        texts.append("Now we just need to fill up the hole.\nClick again on the shovel button.")
        texts.append("During the period of tree growing, there might be many dangers\nwe need to look out for. Our plant needs water.\nClick on the button with the water drop icon.")
        texts.append("Our plant is now in the process of growing.\nLook out for an insects who might try to eat your cherries.\nYou can get rid of them with the sprayer.")
        texts.append("There are other unwelcome plants and grass growing around our plant.\nYou can dig it with the showel.")
        texts.append("To get rid of shoots, that are growing on our tree, use gardening shears.")
        texts.append("Good luck with your plant!")
        texts.append("Hurray! You did it and have a full grown tree!\nCherry trees take usually few years to start producing cherries,\nbut no worries, it'll pay off in the long run.")
        texts.append("Too bad! Your tree has been constantly attacked by the insects, it can no longer produce cherries.\nYou can plant another tree with the button below.")
        texts.append("Bad luck! Your tree was surrounded by bushes and could no longer get enough minerals to produce cherries.\nYou can plant another tree with the button below.")
        texts.append("Oh no! Your tree didn't get enough water and it dried up.\nYou can plant another tree with the button below.")
        texts.append("Oh no! Your tree didn't get enough water and it dried up.\nYou can plant another tree with the button below.")
        texts.append("Wou! Your tree has become wild because you didn't cut the shoots at the bottom. This is no longer a good tree.\nYou can plant another tree with the button below.")
        instrukcie.text=texts[0]
        instrukcie.fontName = "CabinSketch-Regular"
        instrukcie.fontSize=sceneSize.width/44
        instrukcie.numberOfLines=3
        instrukcie.fontColor = .black
        instrukcie.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height*0.85)
        self.addChild(instrukcie)
        textDole.text = "new Cherry tree"
        textDole.fontName = "CabinSketch-Regular"
        textDole.fontSize = sceneSize.width/30
        textDole.fontColor = .black
        textDole.position = CGPoint(x: sceneSize.width/2, y: sceneSize.height*0.1)
        textDole.zPosition=100
        textDole.name="butonMenu2"
        self.addChild(textDole)
        butonMenu.size=CGSize(width: sceneSize.width/4, height: sceneSize.width/4*0.2)
        butonMenu.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height*0.11)
        butonMenu.color = UIColor(hue: 42/365, saturation: 0.3, brightness: 0.69, alpha: 1)
        butonMenu.zPosition=90
        butonMenu.name="butonMenu"
        self.addChild(butonMenu)
        hodiny=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "clock.png")),size: CGSize(width: sizeScn.width/12, height: sizeScn.width/12))
        hodiny.position=CGPoint(x: sceneSize.width*0.88, y: sceneSize.height*0.64)
        self.addChild(hodiny)
        rucicka.texture = SKTexture(image: #imageLiteral(resourceName: "rucicka.png"))
        rucicka.size.height = sizeScn.width/12
        rucicka.size.width = sizeScn.width/12*0.076
        rucicka.position=CGPoint(x: sceneSize.width*0.88, y: sceneSize.height*0.64)
        self.addChild(rucicka)
        timePassed.text="0 days"
        timePassed.fontSize = 22
        timePassed.fontName = "CabinSketch-Bold"
        timePassed.fontColor = .gray
        timePassed.position = CGPoint(x: sceneSize.width*0.88-(sceneSize.width/200), y: sceneSize.height*0.54)
        self.addChild(timePassed)
        screen.size=sceneSize
        screen.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        screen.color = UIColor(hue: 55/360, saturation: 0.09, brightness: 1, alpha: 1)
        screen.zPosition=200
        screen.alpha=1
        self.addChild(screen)
        
        createButtons()
        plantEngine.position=CGPoint(x: 0, y: -sceneSize.height*0.04)
        plantEngine.create(sceneSize: sceneSize)
        self.addChild(plantEngine)
        screen.run(.fadeAlpha(to: 0, duration: 0.4))
    }
    private func createButtons() {
        buttons.append(SKSpriteNode(texture: watBTex[1], size: CGSize(width: sizeScn.width/12, height: sizeScn.width/12)))
        buttons.last?.position = CGPoint(x: sizeScn.width*0.12, y: sizeScn.height*0.16)
        self.addChild(buttons.last!)
        buttons.last?.name="water"
        
        buttons.append(SKSpriteNode(texture: kopBTex[0], size: CGSize(width: sizeScn.width/12, height: sizeScn.width/12)))
        buttons.last?.position = CGPoint(x: sizeScn.width*0.12, y: sizeScn.height*0.28)
        self.addChild(buttons.last!)
        buttons.last?.name="dig"
        
        buttons.append(SKSpriteNode(texture: sprejBTex[1], size: CGSize(width: sizeScn.width/12, height: sizeScn.width/12)))
        buttons.last?.position = CGPoint(x: sizeScn.width*0.12, y: sizeScn.height*0.4)
        self.addChild(buttons.last!)
        buttons.last?.name="sprej"
        
        buttons.append(SKSpriteNode(texture: nozBTex[1], size: CGSize(width: sizeScn.width/12, height: sizeScn.width/12)))
        buttons.last?.position = CGPoint(x: sizeScn.width*0.12, y: sizeScn.height*0.52)
        self.addChild(buttons.last!)
        buttons.last?.name="noznice"
        
        buttons.append(SKSpriteNode(texture: semBTex[1], size: CGSize(width: sizeScn.width/12, height: sizeScn.width/12)))
        buttons.last?.position = CGPoint(x: sizeScn.width*0.12, y: sizeScn.height*0.64)
        self.addChild(buttons.last!)
        buttons.last?.name="zasadit"
    }
    func changeText(to:Int) {
        if to == -1 {
            instrukcie.text=""
        } else {
            instrukcie.text=self.texts[to]
        }
        
    }
    func blockButtons(block:Bool) {
        if block {
            blockedButtons=true
            buttons[0].texture=watBTex[1]
            buttons[1].texture=kopBTex[1]
            buttons[2].texture=sprejBTex[1]
            buttons[3].texture=nozBTex[1]
        } else {
            blockedButtons=false
            buttons[0].texture=watBTex[0]
            buttons[1].texture=kopBTex[0]
            buttons[2].texture=sprejBTex[0]
            buttons[3].texture=nozBTex[0]
        }
    }
    func startClock() {
        rucicka.run(.repeat(.rotate(byAngle: -6.283, duration: 5), count: 18))
        //rucicka.run(.repeatForever(.rotate(byAngle: -6.283, duration: 5)))
        timePassed.text="1 week"
        tickClock(temp: 1)
        
    }
    private func tickClock(temp:Int) {
        self.hodiny.run(.wait(forDuration: 5),completion: {
            if temp>3 && temp < 24{
                self.timePassed.text = temp==4 ? "\((temp)/2) months" : "\((temp)/2) months"
                self.tickClock(temp: temp+2)
            } else if temp>23 && temp<144{
                self.timePassed.text = temp==24 ? "\((temp)/24) year" : "\((temp)/24) years"
                self.tickClock(temp:temp+24)
            } else if temp<144{
                self.timePassed.text="\(temp+1) weeks"
                self.tickClock(temp:temp+1)
            }
            
            
        })
    }
}

class PlantEngine:SKNode {
    private var sceneSize=CGSize(width: 1, height: 1)
    
    public var didDigholeonce=false
    public var didDigholetwice=false
    public var addedPlant=false
    public var finishedTutorial=false
    public var druhaFaza=false
    
    private var kruh=SKSpriteNode(texture: SKTexture(imageNamed: "kruhy"))
    private var zem1=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "zem1.png")))
    private var zemina=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "zemina.png")))
    private var zem2=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "zem2.png")))
    private var zem3=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "zem3.png")))
    private var zavodnenie=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "zavodnene.png")))
    
    private var ciara=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "ciara.png")))
    private var zem5=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "zem5.png")))
    private var zem6=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "zem6.png")))
    private var prsanie=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "vodanie1.png")))
    private var prsal=[SKTexture(image: #imageLiteral(resourceName: "vodanie1.png")),SKTexture(image: #imageLiteral(resourceName: "vodanie2.png")),SKTexture(image: #imageLiteral(resourceName: "vodanie3.png"))]
    private var burinaL=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "burina1l.png")))
    private var burinyL=[SKTexture(image: #imageLiteral(resourceName: "burina1l.png")),SKTexture(image: #imageLiteral(resourceName: "burina2l.png")),SKTexture(image: #imageLiteral(resourceName: "burina3l.png")),SKTexture(image: #imageLiteral(resourceName: "burina4l.png"))]
    private var burinaP=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "burina1p.png")))
    private var burinyP=[SKTexture(image: #imageLiteral(resourceName: "burina1p.png")),SKTexture(image: #imageLiteral(resourceName: "burina2p.png")),SKTexture(image: #imageLiteral(resourceName: "burina3p.png")),SKTexture(image: #imageLiteral(resourceName: "burina4p.png"))]
    private var komare1=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "komare1.png")))
    private var komare2=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "komare2.png")))
    private var komare3=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "komare3.png")))
    private var sprejovanie=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "sprejovanie.png")))
    private var divina=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "divina1.png")))
    private var divinaTex=[SKTexture(image: #imageLiteral(resourceName: "divina1.png")),SKTexture(image: #imageLiteral(resourceName: "divina2.png")),SKTexture(image: #imageLiteral(resourceName: "divina3.png")),SKTexture(image: #imageLiteral(resourceName: "divina4.png"))]
    
    
     private var strom=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "koren1.png")))
     private var stromTex=[SKTexture(image: #imageLiteral(resourceName: "koren1.png")),SKTexture(image: #imageLiteral(resourceName: "koren2.png")),SKTexture(image: #imageLiteral(resourceName: "koren3.png")),SKTexture(image: #imageLiteral(resourceName: "koren4.png")),SKTexture(image: #imageLiteral(resourceName: "koren5.png")),SKTexture(image: #imageLiteral(resourceName: "koren6.png")),SKTexture(image: #imageLiteral(resourceName: "koren7.png"))]
    private var stromTex2=[SKTexture(image: #imageLiteral(resourceName: "koren7.png")),SKTexture(image: #imageLiteral(resourceName: "koren8.png")),SKTexture(image: #imageLiteral(resourceName: "koren9.png")),SKTexture(image: #imageLiteral(resourceName: "koren10.png")),SKTexture(image: #imageLiteral(resourceName: "koren11.png")),SKTexture(image: #imageLiteral(resourceName: "koren12.png"))]
    private var stromTex3=[SKTexture(image: #imageLiteral(resourceName: "koren14.png")),SKTexture(image: #imageLiteral(resourceName: "koren15.png")),SKTexture(image: #imageLiteral(resourceName: "koren16.png")),SKTexture(image: #imageLiteral(resourceName: "koren17.png")),SKTexture(image: #imageLiteral(resourceName: "koren18.png")),SKTexture(image: #imageLiteral(resourceName: "koren19.png")),SKTexture(image: #imageLiteral(resourceName: "koren20.png"))]
     private var listy=SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "listy8.png")))
     private var listyTex=[SKTexture(image: #imageLiteral(resourceName: "listy8.png")),SKTexture(image: #imageLiteral(resourceName: "listy9.png")),SKTexture(image: #imageLiteral(resourceName: "listy10.png")),SKTexture(image: #imageLiteral(resourceName: "listy11.png")),SKTexture(image: #imageLiteral(resourceName: "listy12.png")),SKTexture(image: #imageLiteral(resourceName: "listy13.png"))]
    private var listyTex2=[SKTexture(image: #imageLiteral(resourceName: "listy14.png")),SKTexture(image: #imageLiteral(resourceName: "listy15.png")),SKTexture(image: #imageLiteral(resourceName: "listy16.png")),SKTexture(image: #imageLiteral(resourceName: "listy17.png")),SKTexture(image: #imageLiteral(resourceName: "listy18.png")),SKTexture(image: #imageLiteral(resourceName: "listy19.png")),SKTexture(image: #imageLiteral(resourceName: "listy20.png")),SKTexture(image: #imageLiteral(resourceName: "listy201.png"))]
     
    
    func create (sceneSize:CGSize) {
        self.sceneSize=sceneSize
        kruh.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        kruh.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(kruh)
        ciara.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        ciara.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(ciara)
        zem1.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        zem1.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(zem1)
        zemina.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        zemina.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(zemina)
        zem2.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        zem2.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(zem2)
        zem3.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        zem3.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(zem3)
        
        zavodnenie.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        zavodnenie.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(zavodnenie)
        zem5.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        zem5.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(zem5)
        zem6.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        zem6.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(zem6)
        
        prsanie.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        prsanie.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(prsanie)
        burinaL.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        burinaL.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(burinaL)
        burinaP.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        burinaP.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(burinaP)
        komare1.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        komare1.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(komare1)
        komare2.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        komare2.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(komare2)
        komare3.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        komare3.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(komare3)
        sprejovanie.position=CGPoint(x: sceneSize.width/2-sceneSize.width*0.1*0.85, y: sceneSize.height/2)
        sprejovanie.size=CGSize(width: sceneSize.width*0.1*0.85, height: sceneSize.width*0.1)
        self.addChild(sprejovanie)
        divina.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        divina.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(divina)
        
        strom.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        strom.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(strom)
        listy.position=CGPoint(x: sceneSize.width/2, y: sceneSize.height/2)
        listy.size=CGSize(width: sceneSize.width*0.4*0.85, height: sceneSize.width*0.4)
        self.addChild(listy)
        
        komare1.zPosition=100
        komare2.zPosition=100
        komare3.zPosition=100
        prsanie.zPosition=99
        strom.zPosition=80
        listy.zPosition=84
        divina.zPosition=82
        sprejovanie.zPosition=101
        burinaL.zPosition=70
        burinaP.zPosition=70
        ciara.zPosition=90
        kruh.zPosition=4
        zavodnenie.zPosition=20
        
        zem1.zPosition=12
        zem2.zPosition=13
        zem3.zPosition=13
        zemina.zPosition=16
        zem5.zPosition=17
        zem6.zPosition=17
        
        zavodnenie.alpha=0
        sprejovanie.alpha=0
        prsanie.alpha=0
        komare1.alpha=0
        komare2.alpha=0
        komare3.alpha=0
        listy.alpha=0
        divina.isHidden=true
        strom.isHidden=true
        zem2.alpha=0
        zem3.alpha=0
        //prsanie.run(.repeat(.animate(with: prsal, timePerFrame: 0.07), count: 12))
        
    }
    //----scenario
    func digHole(first:Bool) {
        if first {
            zem6.isHidden=true
            didDigholeonce=true
        } else {
            zem5.texture=SKTexture(imageNamed: "zem5t")
            didDigholetwice=true
        }
    }
    func addPlant() {
        strom.isHidden=false
        addedPlant=true
    }
    func putDirt() {
        zem6.texture=SKTexture(imageNamed: "zem6t")
        zem6.isHidden=false
        didDigholetwice=false
    }
    func firstWatered(){
        zavodnenie.alpha=0.5
        zavodnenie.run(.fadeAlpha(to: 0, duration: 8))
        prsanie.run(.fadeAlpha(to: 1, duration: 0))
        prsanie.run(.fadeAlpha(to: 0, duration: 3))
        prsanie.run(.repeat(.animate(with: prsal, timePerFrame: 0.07), count: 24))
        komareAnim()
        finishedTutorial=true
        burinaL.run(.animate(with: burinyL, timePerFrame: 8))
        burinaP.run(.animate(with: burinyP, timePerFrame: 8))
        komare1.run(.wait(forDuration: 10),completion: {
            self.komare1.alpha=1
        })
        komare2.run(.wait(forDuration: 15),completion: {
            self.komare2.alpha=1
        })
        komare3.run(.wait(forDuration: 20),completion: {
            self.komare3.alpha=1
        })
        strom.run(.animate(with: stromTex, timePerFrame: 2),completion: {
            [self] in
            druhaFaza=true
            zem5.texture=SKTexture(imageNamed: "zem5")
            zem6.texture=SKTexture(imageNamed: "zem6")
            divina.isHidden=false
            divina.run(.animate(with: divinaTex, timePerFrame: 8))
            listy.run(.animate(with: listyTex, timePerFrame: 4))
            strom.run(.animate(with: stromTex2, timePerFrame: 4),completion: {
                [self] in
                listy.run(.animate(with: listyTex2, timePerFrame: 7.8))
                strom.run(.animate(with: stromTex3, timePerFrame: 7.8))
            })
        })
    }
    //-----first
    func watered() {
        prsanie.removeAllActions()
        listy.removeAction(forKey: "listyOpad")
        zavodnenie.run(.fadeAlpha(to: 0.5, duration: 0))
        zavodnenie.run(.fadeAlpha(to: 0, duration: 8))
        prsanie.run(.fadeAlpha(to: 1, duration: 0))
        prsanie.run(.fadeAlpha(to: 0, duration: 3))
        prsanie.run(.repeat(.animate(with: prsal, timePerFrame: 0.07), count: 24))
        if druhaFaza {
            listy.run(.fadeAlpha(to: 1, duration: 0))
            listy.run(.wait(forDuration: 3),completion: {
                [self]in
                listy.run(.fadeAlpha(to: 0, duration: 14),withKey: "listyOpad")
            })
        }
        
    }
    func digg() {
        burinaL.removeAllActions()
        burinaP.removeAllActions()
        burinaL.isHidden=true
        burinaP.isHidden=true
        zem2.run(.fadeAlpha(to: 1, duration: 0))
        zem2.run(.fadeAlpha(to: 0, duration: 8))
        zem3.run(.fadeAlpha(to: 1, duration: 0))
        zem3.run(.fadeAlpha(to: 0, duration: 8))
        burinaL.run(.wait(forDuration: 8),completion: {
            [self] in
            burinaL.isHidden=false
            burinaP.isHidden=false
            burinaL.run(.animate(with: burinyL, timePerFrame: 8))
            burinaP.run(.animate(with: burinyP, timePerFrame: 8))
        })
        
    }
    func sprej() {
        sprejovanie.run(.fadeAlpha(to: 1, duration: 0))
        sprejovanie.run(.fadeAlpha(to: 0, duration: 1.4))
        sprejovanie.run(.scale(to: 3, duration: 1.4))
        komare1.run(.fadeAlpha(to: 0, duration: 1.4))
        komare2.run(.fadeAlpha(to: 0, duration: 1.4))
        komare3.run(.fadeAlpha(to: 0, duration: 1.4),completion: {
            [self]in
            komare1.removeAllActions()
            komare2.removeAllActions()
            komare3.removeAllActions()
            komareAnim()
            komare1.run(.wait(forDuration: 11),completion: {
                self.komare1.alpha=1
            })
            komare2.run(.wait(forDuration: 16),completion: {
                self.komare2.alpha=1
            })
            komare3.run(.wait(forDuration: 21),completion: {
                self.komare3.alpha=1
            })
        })
        sprejovanie.run(.moveBy(x: sceneSize.width/8, y: 0, duration: 1.4),completion: {
            self.sprejovanie.run(.scale(to: 1, duration: 0))
            self.sprejovanie.run(.moveBy(x: -self.sceneSize.width/8, y: 0, duration: 0))
        })
        
    }
    func strihanie() {
        divina.isHidden=true
        divina.removeAllActions()
        divina.run(.wait(forDuration: 8),completion: {
            [self]in
            divina.isHidden=false
            divina.run(.animate(with: divinaTex, timePerFrame: 8))
        })
    }
    
    
    private func komareAnim() {
        let mov4 = SKAction.moveBy(x: -sceneSize.width*0.003, y: 0, duration: 0.14)
        mov4.timingMode = .easeInEaseOut
        let mov5 = SKAction.moveBy(x: sceneSize.width*0.003, y: 0, duration: 0.14)
        mov5.timingMode = .easeInEaseOut
        let seq = SKAction.sequence([mov4,mov5])
        let seq2 = SKAction.sequence([mov5,mov4])
        let seq3 = SKAction.sequence([mov4,mov5])
        komare1.run(.wait(forDuration: 0.07),completion: {
            self.komare1.run(.repeatForever(seq))
        })
        komare2.run(.repeatForever(seq2))
        komare3.run(.repeatForever(seq3))
    }
}


enum PlScenes {
    case start
    case menu
    case plant
}
