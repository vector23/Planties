

README

_____
Used font Cabin Sketch under the license from other party. Under the SIL Open Font License(OFL). Link to the website: https://www.1001fonts.com/cabin-sketch-font.html#license
Font by Impallari Type


------




Juraj Kebis